<?php
include('header.php');
include('query.php');

$image = "";

if (isset($profile_data['image'])) {
    $image = $profile_data['image'];
}
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="row">
            <h2 class="mb-4 text-center">
                <?php
                if (isset($_POST['id'])) {
                    echo "Update Account";
                } else {
                    echo "Add New Account";
                }
                ?>
            </h2>
        </div>
    </div>

    <div class="row">
        <div class="col-6"></div>
        <div class="col-6">
            <a href="users_data.php">
                <button class="btn btn-primary btn-md" style="margin-left:249px;">back</button>
            </a>
        </div>
    </div>
    <div class="row justify-content-center mt-3">
        <div class="col-md-6">
            <form id="add_edit_form" action="" enctype="multipart/form-data" method="POST">
                <?php if (isset($_POST['id'])) { ?>
                <input type="hidden" value="<?php echo $profile_data['user_id']; ?>" name="id">
                <?php } ?>

                <div class="mb-3">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" class="form-control" id="name" name="name"
                        value="<?php if (isset($_POST['id'])) { echo $profile_data['name']; } ?>">
                    <span id="nameError" class="error"></span>
                </div>

                <div class="mb-3">
                    <label for="profileImage" class="form-label">Profile Image</label>
                    <input type="file" class="form-control" id="uploadfile" name="uploadfile">
                    <input type="hidden" value="<?php echo $image; ?>" name="hidden_image" id="hidden_image">
                    <span id="imageError" class="error"></span>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email"
                        value="<?php if (isset($_POST['id'])) { echo $profile_data['email']; } ?>">
                    <span id="emailError" class="error"></span>
                </div>

                <div class="mb-3">
                    <label for="address" class="form-label">Address</label>
                    <input type="text" class="form-control" id="address" name="address"
                        value="<?php if (isset($_POST['id'])) { echo $profile_data['address']; } ?>">
                    <span id="addressError" class="error"></span>
                </div>

                <div class="mb-3">
                    <label for="phone" class="form-label">Phone</label>
                    <input type="tel" class="form-control" id="phone" name="phone"
                        value="<?php if (isset($_POST['id'])) { echo $profile_data['phone']; } ?>" maxlength="10">
                    <span id="phoneError" class="error"></span>
                </div>

                <?php if (!isset($_POST['id'])) { ?>
                <label for="pass" class="form-label">Password</label>
                <div class="form-group eyepos">
                    <input type="password" class="form-control" id="pass" name="pass" value="">
                    <span id="passwordError" class="error"></span>
                    <div class="mine">
                        <button type="button" class="btn toggle-password" onclick="togglePasswordVisibility('pass')">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>

                <label for="confirmPassword" class="form-label">Confirm Password</label>
                <div class="form-group eyepos">
                    <input type="password" class="form-control" id="cpass" name="cpass">
                    <span id="conformpasswordError" class="error"></span>
                    <div class="mine">
                        <button type="button" class="btn toggle-password" onclick="togglePasswordVisibility('cpass')">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
                <?php } ?>

                <br>
                <div class="d-grid gap-2">
                    <button type="button" id="add_edit" class="btn btn-primary btn-block">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include('footer.php') ?>