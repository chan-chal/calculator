<?php
include 'includes/config.php';
if( isset($_POST['id'] ) ){   
    $id = $_POST['id'];
    $fetch_data = "SELECT * FROM `add_edit` WHERE `user_id` = $id";
    $query = mysqli_query($conn, $fetch_data);
    if (!$query) {
        echo "Not getting data";
    } else {
        $profile_data = mysqli_fetch_assoc($query);
    }
}
?>
