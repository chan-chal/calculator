<?php
include('includes/config.php');

$name = $phone = $email = $address = $password = $confirmPassword = '';
$nameErr = $phoneErr = $fileErr = $emailErr = $addressErr = $passwordErr = $confirmPasswordErr = '';

function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $response = array();
    if (empty($_POST['name'])) {
        $nameErr = 'Name is required';
        $response['name'] = $nameErr;
    } else {
        $name = sanitizeInput($_POST['name']);
        if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
            $nameErr = 'Only letters and whitespace allowed';
            $response['name'] = $nameErr;
        }
    }
    if (empty($_FILES['uploadfile']['name'])) {
        $fileErr = 'File upload is required';
        $response['file'] = $fileErr;
    } else {
        $allowedExtensions = ['jpeg', 'jpg', 'avif', 'png'];
        $uploadedFile = $_FILES['uploadfile']['name'];
        echo $uploadedFile;
        $fileExtension = strtolower(pathinfo($uploadedFile, PATHINFO_EXTENSION));
        if (!in_array($fileExtension, $allowedExtensions)) {
            $fileErr = "Invalid file type. Only JPEG, AVIF, and PNG images are allowed.";
            $response['file'] = $fileErr;
        }
    }
    if (empty($_POST['phone'])) {
        $phoneErr = 'Phone number is required';
        $response['phone'] = $phoneErr;
    } else {
        $phone = sanitizeInput($_POST['phone']);
        if (!preg_match('/^[0-9]{10}+$/', $phone)) {
            $phoneErr = "Mobile must have 10 digits";
            $response['phone'] = $phoneErr;
        }
    }
    if (empty($_POST['email'])) {
        $emailErr = 'Email is required';
        $response['email'] = $emailErr;
    } else {
        $email = sanitizeInput($_POST['email']);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = 'Invalid email format';
            $response['email'] = $emailErr; 
        }
    }
    if (empty($_POST['address'])) {
        $addressErr = 'Address is required';
        $response['address'] = $addressErr;
        $address = sanitizeInput($_POST['address']);
    }
    if (empty($_POST['pass'])) {
        $passwordErr = 'Please fill the password';
        $response['password'] = $passwordErr; 
    } else {
        $password = sanitizeInput($_POST['pass']);
        $uppercase = preg_match('@[A-Z]@', $password);
        $lowercase = preg_match('@[a-z]@', $password);
        $number    = preg_match('@[0-9]@', $password);
        $specialChars = preg_match('@[^\w]@', $password);
        if (!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) < 8) {
            $passwordErr = 'Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.';
            $response['password'] = $passwordErr;
        }
    }
    if (empty($_POST['cpass'])) {
        $confirmPasswordErr = 'Confirm password is required';
        $response['confirmPassword'] = $confirmPasswordErr;
    } else {
        $confirmPassword = sanitizeInput($_POST['cpass']);
        if ($confirmPassword !== $password) {
            $confirmPasswordErr = 'Password and confirm password do not match';
            $response['confirmPassword'] = $confirmPasswordErr;
        }
    }
    echo json_encode($response);
    
    if($nameErr = $phoneErr = $fileErr = $emailErr = $addressErr = $passwordErr = $confirmPasswordErr = "")
    {
        $names=$_FILES['uploadfile']['name'];
        $tempname=$_FILES['uploadfile']['tmp_name'];
        $folder="images/".$names;
        move_uploaded_file($tempname,$folder);
        $insert_query="INSERT INTO `add_edit` ('user_id','image','name','email','address','password') VALUES ('$name','$phone','$uploadedFile','$email','$address','$password','$confirmPassword')";
        $query=mysqli_query($conn,$insert_query);
        echo $query;
    }
}
?>
