<?php
include('includes/config.php');

$response = array('status' => 'error', 'message' => 'An error occurred.');

$name = $phone = $email = $address = $password = $confirmPassword = '';
$nameErr = $phoneErr = $fileErr = $emailErr = $addressErr = $passwordErr = $confirmPasswordErr = '';

function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['name'])) {
        $nameErr = 'Name is required';
        $response['name'] = $nameErr;
    } else {
        $name = sanitizeInput($_POST['name']);
        if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
            $nameErr = 'Only letters and whitespace allowed';
            $response['name'] = $nameErr;
        }
    }

    if (empty($_POST['phone'])) {
        $phoneErr = 'Phone number is required';
        $response['phone'] = $phoneErr;
    } else {
        $phone = sanitizeInput($_POST['phone']);
        if (!preg_match('/^[0-9]{10}+$/', $phone)) {
            $phoneErr = "Mobile must have 10 digits";
            $response['phone'] = $phoneErr;
        }
    }

    if (empty($_POST['email'])) {
        $emailErr = 'Email is required';
        $response['email'] = $emailErr;
    } else {
        $email = sanitizeInput($_POST['email']);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = 'Invalid email format';
            $response['email'] = $emailErr; 
        }
    }

    if (empty($_POST['address'])) {
        $addressErr = 'Address is required';
        $response['address'] = $addressErr;
    }
    else{
        $address = sanitizeInput($_POST['address']);
    }

    if (empty($_POST['pass'])) {
        $passwordErr = 'Please fill the password';
        $response['password'] = $passwordErr; 
    } else {
        $password = sanitizeInput($_POST['pass']);
        $uppercase = preg_match('@[A-Z]@', $password);
        $lowercase = preg_match('@[a-z]@', $password);
        $number    = preg_match('@[0-9]@', $password);
        $specialChars = preg_match('@[^\w]@', $password);
        if (!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) < 8) {
            $passwordErr = 'Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.';
            $response['password'] = $passwordErr;
        }
    }

    if (empty($_POST['cpass'])) {
        $confirmPasswordErr = 'Confirm password is required';
        $response['confirmPassword'] = $confirmPasswordErr;
    } else {
        $confirmPassword = sanitizeInput($_POST['cpass']);
        if ($confirmPassword !== $password) {
            $confirmPasswordErr = 'Password and confirm password do not match';
            $response['confirmPassword'] = $confirmPasswordErr;
        }
    }
    
    if(empty($_FILES["uploadfile"]["name"])){
        $fileErr="image is required";
        $response['file'] = $fileErr;
    }else
    {
        $targetDir = "assets/images/";
        $targetFile = $targetDir . basename($_FILES["uploadfile"]["name"]);
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION)); 
        move_uploaded_file($_FILES["uploadfile"]["tmp_name"], $targetFile);
    }

   if($nameErr == "" and
        $phoneErr == "" and 
        $fileErr == "" and 
        $emailErr == "" and 
        $addressErr == "" and 
        $passwordErr == "" and 
        $confirmPasswordErr == "" ) {        
        $insert_query="INSERT INTO `add_edit` (`name`, `image`, `email`, `address`, `phone`, `password`) VALUES ('$name','$targetFile','$email','$address','$phone',md5('$password'))";
        $query=mysqli_query($conn,$insert_query);
        if($query)
        {
            $response = array('status' => 'success', 'message' => 'Insert Successfully !');
        }
        else {
            $response = array('status' => 'error', 'message' => 'Insertion failed.');
        }
        }else{
            $response['status'] = 'error';
            $response['message'] = 'Validation errors';
        }
    echo json_encode($response);
}
?>