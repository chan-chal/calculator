<?php 
    include ('includes/config.php');
    $users_data="SELECT * FROM `add_edit`"; 
    $query=mysqli_query($conn,$users_data);
    include 'header.php';
?>
<div class="container">
    <div class="d-grid gap-2 d-md-flex justify-content-md-end  my-2">
        <a href="add_edit_form.php"><button class="btn btn-secondary" type="button">Add User</button></a>
    </div>
    <table id="example" class="table table-striped" style="width:100%">
        <thead>
            <tr>
                <th>Profile Image</th>
                <th>Name</th>
                <th>Email</th>
                <th>Address</th>
                <th>Phone</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while($details=mysqli_fetch_array($query)) { ?>
            <tr scope="row">
                <td><img src='<?php echo $details['image'];?>' height='80px' width='80px'></td>
                <td><?php echo $details['name'];?></td>
                <td><?php echo $details['email'];?></td>
                <td><?php echo $details['address'];?></td>
                <td><?php echo $details['phone'];?></td>
                <td><button class="btn btn-secondary btn-md">
                        <a style=color:white;
                            href='add_edit_form.php?id=<?php echo $details['user_id'] ?>'>Edit</a></button>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
<?php include 'footer.php' ?>