// $(document).ready(function ($) {
//     $('#add_edit_form').validate({
//         rules: {
//             name: {
//                 required: true,
//                 lettersOnly: true 
//             },
//             uploadfile: 'required',
//             email: 'required',
//             address: 'required',
//             phone: {
//                 required: true,
//                 digits: true,
//                 minlength: 10,
//                 maxlength: 10
//             },
//             pass: {
//                 required: true,
//                 minlength: 8,
//                 strongPassword: true
//             },
//             cpass: {
//                 required: true,
//                 equalTo: "#pass",
//                 minlength: 8,
//                 strongPassword: true
//             },
//         },
//         messages: {
//             name: {
//                 lettersOnly: "Please enter letters only for the name."
//             },
//             uploadfile: 'Please uplaod here',
//             email: 'Please enter valid email',
//             address: 'Enter your address',
//             phone: {
//                 required: 'Enter your phone number',
//                 digits: 'Phone number must contain only digits',
//                 minlength: 'Phone number must be exactly 10 digits',
//                 maxlength: 'Phone number must be exactly 10 digits'
//             },
//             pass: {
//                 required: 'Enter your password',
//                 minlength: 'Password must be at least 8 characters long',
//                 strongPassword: 'Password must include at least 1 special character, 1 capital case letter, and 1 number'
//             },
//             cpass: {
//                 required: 'Enter your confirm password',
//                 equalTo: 'Passwords do not match',
//                 minlength: 'Password must be at least 8 characters long',
//                 strongPassword: 'Password must include at least 1 special character, 1 capital case letter, and 1 number'
//             },
//         },
//     });
//     $.validator.addMethod("lettersOnly", function(value, element) {
//         return this.optional(element) || /^[A-Za-z\s]+$/.test(value);
//     }, "Please enter letters only for the name.");
    
    
//     $.validator.addMethod("strongPassword", function (value, element) {
//         return this.optional(element) ||
//             /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[\W_]).{8,}$/.test(value);
//     }, "Password must include at least 1 special character, 1 capital case letter, and 1 number");
    
// });

// Ajax
$('#add_edit').click(function () {
    if ($('#add_edit_form').valid()) {

        // var request = new FormData();                   
        // $.each(context.prototype.fileData, function(i, obj) { request.append(i, obj.value.files[0]); });    
        // request.append('action', 'upload');
        // request.append('id', response.obj.id);

        $.ajax({
            url: 'action.php',
            method: 'POST',
            data: $('#add_edit_form').serialize(),

           
            success: function (response) {
                response = JSON.parse(response);
                if (response.status == 'success') {
                    // Success handling
                    console.log(response.message);
                    
                } else {
                    console.log(response);   
                    // Update error messages
                    $('#emailError').text(response.email);
                    $('#phoneError').text(response.phone);
                    $('#addressError').text(response.address);
                    $('#passwordError').text(response.password);
                    $('#nameError').text(response.name);
                    $('#conformpasswordError').text(response.confirmPassword);
                    $('#imageError').text(response.file);
                    
                    }
            },
            error: function (xhr, textStatus, errorThrown) {
                console.log(errorThrown);
            }
        });
    }
});

// password eye icon function
function togglePasswordVisibility(inputId) {
    var x = document.getElementById(inputId);
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}
