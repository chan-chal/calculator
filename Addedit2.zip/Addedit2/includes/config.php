<?php
$conn = mysqli_connect('localhost','root','','p1');
    if(!$conn){
        echo "error";
    }
?> 