<?php

$response = array('status' => 'success', 'message' => null);

        if (empty($_POST['name'])) {
            $nameErr = 'Name is required';
            $response = array('status' => 'error', 'message' => $nameErr);

        } else {
            $name = sanitizeInput($_POST['name']);

            if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
                $nameErr = 'Only letters and whitespace allowed';
                $response = array('status' => 'error', 'message' => $nameErr);
            }
        }

        if (empty($_FILES['uploadfile']['name'])) {
            console.log('file not  present');
            $fileErr = 'File upload is required';
            $response = array('status' => 'error', 'message' => $fileErr);

        } else {
              console.log('file is present');
            $allowedExtensions = ['jpeg', 'jpg', 'avif', 'png'];
            $uploadedFile = $_FILES['uploadfile']['name'];
            $fileExtension = strtolower(pathinfo($uploadedFile, PATHINFO_EXTENSION));

            if (!in_array($fileExtension, $allowedExtensions)) {
                $fileErr =  "Invalid file type. Only JPEG, AVIF, and PNG images are allowed.";
             $response = array('status' => 'error', 'message' => $fileErr);

            }
        }

        if (empty($_POST['phone'])) {
            $phoneErr = 'Phone number is required';
            $response = array('status' => 'error', 'message' => $phoneErr);

        } else {
            $phone = sanitizeInput($_POST['phone']);
            if (!preg_match('/^[0-9]{10}+$/', $phone)) {
                $phoneErr = "Mobile must have 10 digits";
                $response = array('status' => 'error', 'message' => $phoneErr);

            }
        }

        if (empty($_POST['email'])) {
            $emailErr = 'Email is required';
            $response = array('status' => 'error', 'message' => $emailErr);

        } else {
            $email = sanitizeInput($_POST['email']);

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $emailErr = 'Invalid email format';
            $response = array('status' => 'error', 'message' => $emailErr);

            }
        }

        if (empty($_POST['address'])) {
            $addressErr = 'Address is required';
            $response = array('status' => 'error', 'message' => $addressErr);

        } else {
            $address = sanitizeInput($_POST['address']);
            $response = array('status' => 'error', 'message' => $addressErr);

        }

        if (empty($_POST['pass'])) {
            $passwordErr = 'Please fill the password';
            $response = array('status' => 'error', 'message' => $passwordErr);

        } else {
            $password = sanitizeInput($_POST['pass']);
            $uppercase = preg_match('@[A-Z]@', $password);
            $lowercase = preg_match('@[a-z]@', $password);
            $number    = preg_match('@[0-9]@', $password);
            $specialChars = preg_match('@[^\w]@', $password);
            if (!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) < 8) {
                $passwordErr = 'Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.';
               $response = array('status' => 'error', 'message' => $passwordErr);

            }
        }

        if (empty($_POST['cpass'])) {
            $confirmPasswordErr = 'Confirm password is required';
            $response = array('status' => 'error', 'message' => $confirmPasswordErr);

        } else {
            $confirmPassword = sanitizeInput($_POST['cpass']);
            if ($confirmPassword !== $password) {
                $confirmPasswordErr = 'Password and confirm password do not match';
                $response = array('status' => 'error', 'message' => $confirmPasswordErr);

                
            }
    echo json_encode($response);

        }
        
?>