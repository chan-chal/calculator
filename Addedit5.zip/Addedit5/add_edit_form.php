<?php include('header.php');

// ($_SERVER["REQUEST_METHOD"]=='POST');
// print_r($_POST);
// die;
?>
<?php if($_SERVER["REQUEST_METHOD"]=='POST'){  ?>
<div class="text-center">
    <img src="<?php  if(isset($_POST['image'])){echo $_POST['image'];} ?>" height='80px' width='80px'>
</div>
<?php } ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <h2 class="mb-4">Add edit form</h2>
            <form id="add_edit_form" action="action.php" enctype="multipart/formdata" method="POST">
                <input type="hidden" value="<?php echo isset($_GET['id']);?>" name="id">

                <div class="mb-3">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php  if(isset($_POST['name'])){echo $_POST['name'];} ?>">
                    <span id="nameError" class="error"></span>

                </div>

                <div class="mb-3">
                    <label for="profileImage" class="form-label">Profile Image</label>
                    <input type="file" class="form-control" id="uploadfile" name="uploadfile">
                    <span id="imageError" class="error"></span>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php  if(isset($_POST['email'])){echo $_POST['email'];} ?>">
                    <span id="emailError" class="error"></span>
                </div>

                <div class="mb-3">
                    <label for="address" class="form-label">Address</label>
                    <input type="text" class="form-control" id="address" name="address" value="<?php  if(isset($_POST['address'])){echo $_POST['address'];} ?>">
                    <span id="addressError" class="error"></span>
                </div>

                <div class="mb-3">
                    <label for="phone" class="form-label">Phone</label>
                    <input type="tel" class="form-control" id="phone" name="phone" maxlength="10" value="<?php if(isset($_POST['phone'])){echo $_POST['phone'];} ?>" >
                    <span id="phoneError" class="error"></span>
                </div>
                <?php if($_SERVER["REQUEST_METHOD"]=='GET'){  ?>

                GET               <label for="pass" class="form-label">Password</label>
                    <div class="form-group eyepos">
                        <input type="password" class="form-control" id="pass" name="pass">
                        <span id="passwordError" class="error"></span>
                        
                    <div class="mine">
                        <button type="button" class="btn toggle-password" onclick="togglePasswordVisibility('pass')">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
                
                <label for="confirmPassword" class="form-label">Confirm Password</label>
                <div class="form-group eyepos">
                    <input type="password" class="form-control" id="cpass" name="cpass">
                    <span id="conformpasswordError" class="error"></span>
                    
                    <div class="mine">
                        <button type="button" class="btn toggle-password" onclick="togglePasswordVisibility('cpass')">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                <?php } else{  ?>

                    <input type="hidden"  name="pass" value="<?php  if(isset($_POST['password'])){echo $_POST['password'];} ?>">
                    <input type="hidden"  name="confirmPassword" value="<?php  if(isset($_POST['password'])){echo $_POST['password'];} ?>">

                    
                <?php } ?>    
                    <br>
                    <div>
                        <button type="button" id="add_edit" class="btn btn-primary">Submit</button>
                    </div>
            </form>
        </div>
    </div>
</div>

<?php include('footer.php') ?>