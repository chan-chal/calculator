<?php 
    include ('includes/config.php');
    $users_data="SELECT * FROM `register`"; 
    $query=mysqli_query($conn,$users_data);
    include 'header.php';
?>
<div class="container">
    <div class="d-grid gap-2 d-md-flex justify-content-md-end  my-2">
        <a href="add_edit_form.php"><button class="btn btn-secondary" type="button">Add User</button></a>
    </div>
    <table id="example" class="table table-striped" style="width:100%">
        <thead>
            <tr>
                <th>Profile Image</th>
                <th>Name</th>
                <th>Email</th>
                <th>Address</th>
                <th>Phone</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while($details=mysqli_fetch_array($query)) { ?>
            <tr scope="row">
                <td><img src='<?php echo $details['image'];?>' height='80px' width='80px'></td>
                <td><?php echo $details['name'];?></td>
                <td><?php echo $details['email'];?></td>
                <td><?php echo $details['address'];?></td>
                <td><?php echo $details['phone'];?></td>
                <td>
                    <form  action="add_edit_form.php"  method="POST">
                        <input type="hidden" value="<?php echo $details['id']; ?>" name="id">
                        <input type="hidden" value="<?php echo $details['name']; ?>" name="name">
                        <input type="hidden" value="<?php echo $details['email']; ?>" name="email">
                        <input type="hidden" value="<?php echo $details['address']; ?>" name="address">
                        <input type="hidden" value="<?php echo $details['password']; ?>" name="password">
                        <input type="hidden" value="<?php echo $details['image']; ?>" name="image">
                        <input type="hidden" value="<?php echo $details['phone']; ?>" name="phone">
                        <button class="btn btn-secondary btn-md" type='submit'>
                            Edit
                        </button>
                    </form>    
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
<?php include 'footer.php' ?>