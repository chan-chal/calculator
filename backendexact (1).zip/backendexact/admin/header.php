<html>
<title> header for admin page(backend) </title>
<body>
<a href="selectforcontactusform.php"> Contact Management(contactus) </a>&nbsp; &nbsp;
<a href="passwd.php">Change Password</a>&nbsp; &nbsp;
<a href="forgot.php">Forgot Password</a>&nbsp; &nbsp;
 &nbsp;<a href="logout.php"> Logout</a>
<body>
</html>
