<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class UserController extends Controller
{
    public function ShowRegisterform()
    {
        return view('register');
    }

    public function userregister(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'address' => 'required|string|max:255',
            'email' => 'required|email',
            'contact_number' => 'required|numeric|digits:10',
            'file' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            'password' => [
                'required',
                'string',
                'min:8',
                'confirmed',
                'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/',
            ],
            'password_confirmation' => 'required|string|min:8',
        ]);

        if (User::where('email', '=', $request->input('email'))->count() > 0) {
            return redirect()->back()->withErrors(['email' => 'User Already Exists.']);
        } else {
            $customer = new User;
            $customer->name = $request['name'];
            $customer->address = $request['address'];
            $customer->email = $request['email'];
            $customer->contact_number = $request['contact_number'];

            if ($request->hasFile('file')) {
                $file = $request->file('file');
                $hashedFilename = $file->store('images', 'public');
                $originalFilename = $file->getClientOriginalName();
                $customer->file = $originalFilename;
            }

            $customer->password = Hash::make($request['password']);
            $customer->save();
            return redirect('loginUser');
        }
    }

    public function viewLogin(Request $request)
    {
        return view('login');
    }

    public function validateLogin(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => [
                'required',
                'string',
                'min:8',
                'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/',
            ],
        ]);

        if (auth()->attempt($request->only('email', 'password'))) {
            $data = Auth::user();
            return view('user-show');
        }
        return view('login')->withErrors(['password' => 'Invalid Credentials']);
    }

    public function profile(Request $request)
    {
        $customer = Auth::user();
        $customer->name = $request['name'];
        $customer->address = $request['address'];
        $customer->email = $request['email'];
        $customer->contact_number = $request['contact_number'];
        $customer->save();
        return view('user-show');
    }

    public function showchangepassword(Request $request)
    {
        return view('passwordchange');
    }

    public function mychangepasswordHit(Request $request)
    {
        $request->validate([
            'oldPassword' => 'required',
            'newPassword' => 'required',
            'password_confirmation' => 'required|same:newPassword',
        ]);

        $user = Auth::user();

        if (Hash::check($request->oldPassword, $user->password)) {
            $user->update([
                'password' => Hash::make($request->newPassword),
            ]);

            return view('user-show')->with('success', 'Password changed successfully.');
        }

        return redirect()->back()->withErrors(['oldPassword' => 'Incorrect current password.']);
    }

    public function logout()
    {
        Auth::logout();
        return redirect('/loginUser');
    }
}
