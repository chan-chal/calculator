{{-- @extends('layouts.master')

@section('area')
<a href="{{route('new')}}">
<button class="btn btn-primary d-inline-block m-2 float-right">Add</button>
</a>
<table class="table mt-5">
    <thead>
      <tr>
        <th scope="col">Name</th>
        <th scope="col">Address</th>
        <th scope="col">Email</th>
        <th scope="col">Contact No.</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      @foreach ($customers as $data)
      <tr>
        <th scope="row">{{$data->name}}</th>
        <td>{{$data->address}}</td>
        <td>{{$data->email}}</td>
        <td>{{$data->contact_number}}</td>
        <td>
            <a href="{{ route('delete', ['id' => $data->id]) }}">
                <button class="btn btn-danger">Delete</button>
            </a>
            <a href="{{ route('edit', ['id' => $data->id]) }}">
                <button class="btn btn-primary">Edit</button>
            </a>
        </td>
        <td></td>
      </tr>
      @endforeach
    </tbody>
  </table>
  @endsection --}}

  @extends('layouts.master')

@section('area')
<a href="{{ route('new') }}">
    <button class="btn btn-primary d-inline-block m-2 float-right">Add</button>
</a>
<table class="table mt-5">
    <thead>
        <tr>
            <th scope="col">Name</th>
            <th scope="col">Address</th>
            <th scope="col">Email</th>
            <th scope="col">Contact No.</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
        <tr>

            <td>{{Auth::user()->name}}</td>
            <td>{{Auth::user()->address}}</td>
            <td>{{Auth::user()->email}}</td>
            <td>{{Auth::user()->contact_number}}</td>
            {{-- <td>{{Auth::user()->name}}</td> --}}
            <td>
                <a href="{{ route('delete', ['id' =>Auth::user()->id]) }}">
                    <button class="btn btn-danger">Delete</button>
                </a>
                <a href="{{ route('edit', ['id' => Auth::user()->id]) }}">
                    <button class="btn btn-primary">Edit</button>
                </a>
                {{-- <a href="{{ route('showUpdatePasswordForm', ['id' => $data->id]) }}">
                    <button class="btn btn-primary">Change Password</button>
                {{-- </a> --}}
            </td>


        {{-- </tr> --}}
        {{-- @foreach ($customers as $data)
        @auth
        @if ($data->id == Auth::user()->id)
        <tr>
            <th scope="row">{{ $data->name }}</th>
            <td>{{ $data->address }}</td>
            <td>{{ $data->email }}</td>
            <td>{{ $data->contact_number }}</td>
            <td>
                <a href="{{ route('delete', ['id' => $data->id]) }}">
                    <button class="btn btn-danger">Delete</button>
                </a>
                <a href="{{ route('edit', ['id' => $data->id]) }}">
                    <button class="btn btn-primary">Edit</button>
                </a>
                {{-- <a href="{{ route('showUpdatePasswordForm', ['id' => $data->id]) }}">
                    <button class="btn btn-primary">Change Password</button>
                </a>
            </td>
            <td></td>
        </tr>
        @endif
        @endauth
        @endforeach --}}
    </tbody>
</table>
@endsection

