@extends('layouts.master')

@section('area')
<div class="row mt-5">
    <div class="card mb-3">
        <div class="row g-0 d-flex align-items-center">
            <div class="col-lg-4 d-none d-lg-flex">
                <img src="https://mdbootstrap.com/img/new/ecommerce/vertical/004.jpg" alt="Trendy Pants and Shoes"
                     class="w-100 rounded-t-5 rounded-tr-lg-0 rounded-bl-lg-5" />
            </div>
            <div class="col-lg-8">
                <div class="card-body py-5 px-md-5">
                    <form method="post" id="restroForm">
                        @csrf
                        <h1>Login here!</h1>
                        <div class="form-outline mt-4 mb-4">
                            <label class="form-label">Email address:</label>
                            <input type="email" name="email" id="email" class="form-control" />
                            <span class="text-danger">
                                @error('email')
                                {{ $message }}
                                @enderror
                            </span>
                        </div>
                        <div class="form-outline mb-4">
                            <label class="form-label">Password:</label>
                            <input type="password" id="password" name="password" class="form-control" />
                            <span class="text-danger">
                                @error('password')
                                {{ $message }}
                                @enderror
                            </span>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block mb-4">Sign in</button>
                        <p class="text-center mt-3">Don't have an account? <a href="{{ url('/') }}">Click here</a></p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
