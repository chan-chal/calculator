@extends('layouts.master')
@section('area')
  <div class="mask d-flex align-items-center h-100 gradient-custom-3">
    <div class="container h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-12 col-md-9 col-lg-7 col-xl-6">
          <div class="card formmargin" style="border-radius: 15px;">
            <div class="card-body p-5">
              <h2 class="text-uppercase text-center mb-5">Update your password</h2>
              @if ($errors->any())
                  <div class="alert alert-danger">
                      <ul>
                          @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                          @endforeach
                      </ul>
                  </div>
              @endif
              <form action="{{url('/changepasswordHit')}}" method="post">
                @csrf

                <label class="font-weight-bold">Old Password</label>
                <div class="input-group">
                <input type="password" class="form-control" name="oldPassword" id="myInput1" value="" placeholder="Old password" required  maxlength="32">
                <div class="input-group-append">
                <button class="btn btn-secondary" type="button" onclick="togglePasswordVisibility('myInput1')"><i class="fa fa-eye" aria-hidden="true"></i></button>
                </div>
                </div>
                <div class="row">
                <span class="error"></span>
                </div>
                <br>


                <label class="font-weight-bold">New password</label>
                <div class="input-group">
                <input type="password" class="form-control" name="newPassword" id="myInput2" placeholder="New password" value="" required  maxlength="32">
                <div class="input-group-append">
                <button class="btn btn-secondary" type="button" onclick="togglePasswordVisibility('myInput2')"><i class="fa fa-eye" aria-hidden="true"></i></button>
                </div>
                </div>
                <div class="row">
                <span class="error"></span>
                </div>
                <br>

                <label class="font-weight-bold">Confirm Newpassword</label>
                <div class="input-group">
                <input type="password" class="form-control" name="password_confirmation" id="myInput3" value="" placeholder="Confirm Newpassword" required  maxlength="32">
                <div class="input-group-append">
                <button class="btn btn-secondary" type="button" onclick="togglePasswordVisibility('myInput3')"><i class="fa fa-eye" aria-hidden="true"></i></button>
                </div>
                </div>
                <div class="row">
                <span class="error"></span>
                </div>
                <br>

                <div class="d-flex justify-content-center">
                  <button type="submit" name="update" class="btn btn-success btn-block btn-lg gradient-custom-4 text-body"><a class="color-change">Update Password</a></button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
