@extends('layouts.master')

@section('area')
<h1>Welcome {{ Auth::user()->name }}</h1>
<form action="{{ url('/update-profile') }}" method="post" id="restroForm" enctype="multipart/form-data">
    @csrf
    <div class="row my-5">
        <div class="col-lg-6" id="background-column">
        </div>
        <div class="col-lg-6" id="form-column">
            <h1 class="text-center" id="form-head">Profile Update</h1>
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" id="name" name="name" value="{{ Auth::user()->name }}">
                <span class="text-danger">
                    @error('name')
                    {{ $message }}
                    @enderror
                </span>
            </div>
            <div class="form-group">
                <label for="address">Address</label>
                <input type="text" class="form-control" id="address" name="address" value="{{ Auth::user()->address }}">
                <span class="text-danger">
                    @error('address')
                    {{ $message }}
                    @enderror
                </span>
            </div>
            {{-- <div class="form-group">
                <label for="file">Select Image</label>
                <input type="file" class="form-control" id="file" name="file" value="">
                <span class="text-danger">
                    @error('file')
                    {{ $message }}
                    @enderror
                </span>
            </div> --}}
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" value="{{ Auth::user()->email }}">
                <span class="text-danger">
                    @error('email')
                    {{ $message }}
                    @enderror
                </span>
            </div>
            <div class="form-group">
                <label for="contact_number">Contact Number</label>
                <input type="text" class="form-control" id="contact_number" name="contact_number" maxlength="10" value="{{ Auth::user()->contact_number }}">
                <span class="text-danger">
                    @error('contact_number')
                    {{ $message }}
                    @enderror
                </span>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Submit</button>
        </div>
    </div>
</form>
<p>
    Change Your password <a href="{{ url('/changepassword') }}">click here</a>
</p>

<a href="{{ url('/logout') }}"
   onclick="event.preventDefault();
            document.getElementById('logout-form').submit();">
    Logout
</a>

<form id="logout-form" action="{{ url('logout') }}" method="POST" style="display: none;">
    @csrf
</form>
@endsection
