<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Models\Users;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


// register page
Route::get('/',[UserController::class,'ShowRegisterform']);
Route::post('/registeruser',[UserController::class,'userregister']);

// login user
Route::get('/loginUser',[UserController::class,'viewLogin'])->name('login');
Route::post('/loginUser',[UserController::class,'validateLogin']);

// table
Route::get('/view',[UserController::class,'view']);
Route::post('/view',[UserController::class,'view']);
// delete user
Route::get('/delete/{id}',[UserController::class,'delete'])->name('delete');

// profile update
Route::get('/user-update',[UserController::class,'showUpdate']);
Route::post('/update-profile',[UserController::class,'profile']);

// change password
Route::get('/changepassword',[UserController::class,'showchangepassword']);
Route::post('/changepasswordHit',[UserController::class,'mychangepasswordHit']);

// logout
Route::post('/logout',[UserController::class,'logout']);



