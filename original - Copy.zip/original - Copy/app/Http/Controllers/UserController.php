<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Users;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function registerUser( ){
        $url=url('/userReg');
        $title="Customer Registration";
        $data=compact('url','title');
        return view('register')->with($data);
    }

    public function ShowRegisterData(Request $request){
        $request->validate(
            $rules = [
                        'name' => 'required|string|max:255',
                        'address' => 'required|string|max:255',
                        'email' => 'required|email',
                        'contact_number' => 'required|numeric|digits:10',
                        'file' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
                        'password' => [
                        'required',
                        'string',
                        'min:8',
                        'confirmed',
                        'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/',
                                     ],
                        'password_confirmation' => 'required|string|min:8',
            ]
        );
                        $url=url('/userReg');
                        $title="Customer Registration";
                        $data=compact('url','title');
                        $customer = new users;
                        $customer->name=$request['name'];
                        $customer->address=$request['address'];
                        $customer->email=$request['email'];
                        $customer->contact_number=$request['contact_number'];
                        // if ($request->hasFile('file')) {
                        //     $file = $request->file('file');
                        //     $path = $file->store('images', 'public'); // Store in the 'public/images' directory
                        //     $customer->file = $path; // Save the image path in the database
                        // }
                        if ($request->hasFile('file')) {
                            $file = $request->file('file');
                            $hashedFilename = $file->store('images', 'public');
                            $originalFilename = $file->getClientOriginalName();
                            $customer->file = $originalFilename;
                        }
                        $customer->password = Hash::make($request['password']);
                        $customer->save();
                        return redirect('loginUser');
    }
        public function view() {
            $customers = users::all();
        return view('CustomerView', compact('customers'));
    }
        public function delete($id) {
            $customers=Users::find($id);
            if(is_null($customers)){
                $customers->delete();
            }
            return redirect('view');
    }
    public function edit($id){
        $customer = Users::find($id);

        if(is_null($customer)){
            return redirect('view');
        } else {
                $isCreating = true;
                $url=url('update')."/".$id;
                $title = "Edit Customer";
                return view('register', compact('customer', 'url', 'title','isCreating'));
        }
    }
    public function update($id,Request $request){
        $customer= users::find($id);
        $customer->name=$request['name'];
        $customer->address=$request['address'];
        $customer->email=$request['email'];
        $customer->contact_number=$request['contact_number'];
        $customer->save();
        return redirect('view');
    }

    public function viewLogin(Request $login){
        return view('login');
    }

    public function validateLogin(Request $login){
        $login->validate([
            'email' => 'required|email',
            'password' => [
                'required',
                'string',
                'min:8',
                'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/',
            ],
        ]);
        if(auth()->attempt(request()->only(['email','password']))){
            return redirect('view');
        }
        return view('login')->withErrors(['password'=>"Invalid Credentials"]);
    }
}
