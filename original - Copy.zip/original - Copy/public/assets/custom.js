jQuery(document).ready(function () {
        $('#restroForm').validate({
        // console.log("Script loaded");
            rules: {
                name: {
                    required: true,
                    lettersOnly: true
                },
                address: {
                    required: true
                },
                file: {
                    required: true
                },
                // Add more validation rules for other fields
                email: {
                    required: true,
                    email: true
                },
                contact_number: {
                    required: true,
                    digits: true,
                    minlength: 10,
                    maxlength: 10
                },

                // @if(!isset($customer))

                password: {
                    required: true,
                    minlength: 8, // Adjust the minimum password length as needed
                    strongPassword: true
                },
                password_confirmation: {
                    required: true,
                    equalTo: '#password' // Ensure the password confirmation matches the password field
                }
                // @endif
            },
            messages: {
                name: {
                    required: "Please enter your name."
                },
                address: {
                    required: "Please enter your address."
                },
                file: {
                    required: "Please upload file."
                },
                // Add more error messages for other fields
                email: {
                    required: "Please enter your email.",
                    email: "Please enter a valid email address."
                },
                contact_number: {
                    required: "Please enter your contact number.",
                    digits: "Please enter only digits.",
                    minlength: "Please enter a 10-digit number.",
                    maxlength: "Please enter a 10-digit number."
                },
                // @if(!isset($customer))
                password: {
                    required: "Please enter a password.",
                    minlength: "Password must be at least 8 characters long."
                },
                password_confirmation: {
                    required: "Please confirm your password.",
                    equalTo: "Passwords do not match."
                }
                // @endif
            }
        });

    $.validator.addMethod("lettersOnly", function (value, element) {
        return this.optional(element) || /^[A-Za-z\s]+$/.test(value);
    }, "Please enter letters only for the name.");

    $.validator.addMethod("strongPassword", function (value, element) {
        return this.optional(element) ||
            /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[\W_]).{8,}$/.test(value);
    }, "Password must include at least 1 special character, 1 capital case letter, and 1 number");

    });



