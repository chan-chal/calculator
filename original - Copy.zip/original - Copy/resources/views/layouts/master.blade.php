@include('includes.header')
<div class="container">
    @yield('area')
</div>
@include('includes.footer')
