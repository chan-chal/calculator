@extends('layouts.master')

@section('area')
<form action="{{$url}}" method="post" id="restroForm" enctype="multipart/form-data">
    @csrf
    <div class="row my-5">
        <div class="col-lg-6" id="background-column">
        </div>
        <div class="col-lg-6" id="form-column">
            <h1 class="text-center" id="form-head">{{$title}}</h1>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name"  value="{{ old('name', $customer->name ?? '') }}">
                    <span class="text-danger">
                        @error('name')
                            {{$message}}
                        @enderror
                    </span>
                </div>
                <div class="form-group">
                    <label for="Address">Address</label>
                    <input type="text" class="form-control" id="address" name="address"  value="{{ old('address', $customer->address ?? '') }}">
                    <span class="text-danger">
                        @error('address')
                            {{$message}}
                        @enderror
                    </span>
                </div>
                <div class="form-group">
                    <label for="file">Select Image</label>
                    <input type="file" class="form-control" id="file" name="file" value="">
                    <span class="text-danger">
                        @error('file')
                            {{$message}}
                        @enderror
                    </span>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email"  value="{{ old('email', $customer->email ?? '') }}">
                    <span class="text-danger">
                        @error('email')
                            {{$message}}
                        @enderror
                    </span>
                </div>
                <div class="form-group">
                    <label for="contact_number">Contact Number</label>
                    <input type="text" class="form-control" id="contact_number" name="contact_number" maxlength="10"  value="{{ old('contact_number', $customer->contact_number ?? '') }}">
                    <span class="text-danger">
                        @error('contact_number')
                            {{$message}}
                        @enderror
                    </span>
                </div>
                @if(!isset($customer))
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password" >
                    <span class="text-danger">
                        @error('password')
                            {{$message}}
                        @enderror
                    </span>
                </div>
                <div class="form-group">
                    <label for="cpassword">Confirm Password</label>
                    <input type="password" class="form-control" id="cpassword" name="password_confirmation" >
                    <span class="text-danger">
                        @error('password_confirmation')
                            {{$message}}
                        @enderror
                    </span>
                </div>
                @endif
                <button type="submit" class="btn btn-primary btn-block">Submit</button>
        </div>
    </div>
</form>
@endsection
