@extends('layouts.master')

@section('area')
<form action="{{$url}}" method="post">
    @csrf
    <div class="row my-5">
        <div class="col-lg-6" id="background-column">
        </div>
        <div class="col-lg-6" id="form-column">
            <h1 class="text-center" id="form-head">{{$title}}</h1>
            <form>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="{{ old('name', $customer->name ?? '') }}">
                    <span class="text-danger">
                        @error('name')
                            {{$message}}
                        @enderror
                    </span>
                </div>
                <div class="form-group">
                    <label for="Address">Address</label>
                    <input type="text" class="form-control" id="address" name="address" value="{{ old('address', $customer->address ?? '') }}">
                    <span class="text-danger">
                        @error('address')
                            {{$message}}
                        @enderror
                    </span>
                </div>
                {{-- <div class="form-group">
                    <label for="file">Select Image</label>
                    <input type="file" class="form-control" id="file" name="file" value="">
                    <span class="text-danger">
                        @error('country')
                            {{$message}}
                        @enderror
                    </span>
                </div> --}}
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="{{ old('email', $customer->email ?? '') }}">
                    <span class="text-danger">
                        @error('email')
                            {{$message}}
                        @enderror
                    </span>
                </div>
                <div class="form-group">
                    <label for="contact_number">Contact Number</label>
                    <input type="text" class="form-control" id="contact_number" name="contact_number" maxlength="10" value="{{ old('contact_number', $customer->contact_number ?? '') }}">
                    <span class="text-danger">
                        @error('contact_number')
                            {{$message}}
                        @enderror
                    </span>
                </div>
                @if(!isset($customer))
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password" >
                    <span class="text-danger">
                        @error('password')
                            {{$message}}
                        @enderror
                    </span>
                </div>
                <div class="form-group">
                    <label for="cpassword">Confirm Password</label>
                    <input type="password" class="form-control" id="cpassword" name="password_confirmation" >
                    <span class="text-danger">
                        @error('password_confirmation')
                            {{$message}}
                        @enderror
                    </span>
                </div>
                @endif
                <button type="submit" class="btn btn-primary btn-block">Submit</button>
            </form>
        </div>
    </div>
</form>
@endsection







<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Users;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function reg( ){

        $url=url('/view');
        // dd($url);
        $title="Customer Registration";
        $data=compact('url','title');
        return view('register')->with($data);
    }

    public function ShowRegisterData(Request $request){
        $request->validate(
            $rules = [
                        'name' => 'required|string|max:255',
                        'address' => 'required|string|max:255',
                        'email' => 'required|email',
                        'contact_number' => 'required|numeric|digits:10',
                        'password' => [
                        'required',
                        'string',
                        'min:8',
                        'confirmed',
                        'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/',
                                     ],
                        'password_confirmation' => 'required|string|min:8',
            ]
        );
                        $customer = new users;
                        $customer->name=$request['name'];
                        $customer->address=$request['address'];
                        $customer->email=$request['email'];
                        $customer->contact_number=$request['contact_number'];
                        $customer->password = Hash::make($request['password']);
                        $customer->save();
                        return redirect('view');
    }
        public function view() {
            $customers = users::all();
        return view('CustomerView', compact('customers'));
    }
        public function delete($id) {
            $customers=Users::find($id);
            if(is_null($customers)){
                $customers->delete();
            }
            return redirect('view');
    }
    public function edit($id){
        $customer = Users::find($id);

        if(is_null($customer)){
            return redirect('view');
        } else {
                $isCreating = true;
                $url=url('update')."/".$id;
                $title = "Edit Customer";
                return view('register', compact('customer', 'url', 'title','isCreating'));
        }
    }
    public function update($id,Request $request){
        $customer= users::find($id);
        // $isCreating = true;
        $customer->name=$request['name'];
        $customer->address=$request['address'];
        $customer->email=$request['email'];
        $customer->contact_number=$request['contact_number'];
        $customer->save();
        return redirect('view');
    }
}

