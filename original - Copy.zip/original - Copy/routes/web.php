<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Models\Users;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/registerhere',[UserController::class,'registerUser'])->name('new');
// Route::get('/register', [App\Http\Controllers\UserController::class, 'register']);
Route::post('/userReg',[UserController::class,'ShowRegisterData'])->name('userReg');
Route::get('/view',[UserController::class,'view']);
Route::post('/view',[UserController::class,'view']);
Route::get('/delete/{id}',[UserController::class,'delete'])->name('delete');
Route::get('/edit/{id}',[UserController::class,'edit'])->name('edit');
Route::post('/update/{id}',[UserController::class,'update'])->name('update');
Route::get('/update',[UserController::class,'update']);
Route::get('/loginUser',[UserController::class,'viewLogin'])->name('login');
Route::post('/loginUser',[UserController::class,'validateLogin']);

// Route::get('/loginUser',function(){
//     // $users= users::all();
//     return view('login');
// });

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
