  

<?php $__env->startSection('area'); ?>
<a href="<?php echo e(route('new')); ?>">
    <button class="btn btn-primary d-inline-block m-2 float-right">Add</button>
</a>
<table class="table mt-5">
    <thead>
        <tr>
            <th scope="col">Name</th>
            <th scope="col">Address</th>
            <th scope="col">Email</th>
            <th scope="col">Contact No.</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(auth()->guard()->check()): ?>
        <?php if($data->id == Auth::user()->id): ?>
        <tr>
            <th scope="row"><?php echo e($data->name); ?></th>
            <td><?php echo e($data->address); ?></td>
            <td><?php echo e($data->email); ?></td>
            <td><?php echo e($data->contact_number); ?></td>
            <td>
                <a href="<?php echo e(route('delete', ['id' => $data->id])); ?>">
                    <button class="btn btn-danger">Delete</button>
                </a>
                <a href="<?php echo e(route('edit', ['id' => $data->id])); ?>">
                    <button class="btn btn-primary">Edit</button>
                </a>
            </td>
            <td></td>
        </tr>
        <?php endif; ?>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-crud\resources\views/CustomerView.blade.php ENDPATH**/ ?>