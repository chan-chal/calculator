<?php include('header.php') ?>
<div class="background-image">
    <div class="container">
        <div class="row justify content-center">
            <div class="col-6">
            <h2 class="mb-4">Weather Check</h2>
                <form action="query.php" method="post">
                    <label for="weather_input">Enter City:</label>
                    <div class="form-group mb-3">
                        <input type="text" id="weather_input" name="city"class="">
                    </div>
                        <button type="submit" name="submit"class="btn btn-primary btn-md btn-block">Get Weather</button>
                </form>
            </div>    
        </div>
    </div>
</div>
<?php include('footer.php') ?>
    

