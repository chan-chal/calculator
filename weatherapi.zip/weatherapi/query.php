<?php
if(isset($_POST['submit'])){
    if(!empty($_POST['city'])){
    $city=$_POST['city'];
    $api_key="01f3d262b72a0f5b1d9084a16f6d7b33";
    $api = "https://api.openweathermap.org/data/2.5/weather?q=".urlencode($city)."&appid=".$api_key;
    $api_data=file_get_contents($api);
    print_r($api_data);
    }else{
    echo "Enter  city";
    }
}
?>